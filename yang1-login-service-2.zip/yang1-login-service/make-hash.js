const readline = require("readline-sync");
const bcrypt = require("bcryptjs");

const password = readline.question("로그인 비밀번호를 입력하세요 (화면에 표시되지 않음): ", {
  hideEchoBack: true
});
if (!password) {
  console.error("\n비밀번호가 비어 있습니다.");
  process.exit(1);
}
const hash = bcrypt.hashSync(password, 12);
console.log("\n호스팅 서비스의 LOGIN_PASSWORD_HASH 환경 변수에 아래 값을 넣으세요:\n");
console.log(hash);
