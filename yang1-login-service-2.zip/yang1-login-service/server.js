require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const cookieSession = require("cookie-session");
const bcrypt = require("bcryptjs");
const rateLimit = require("express-rate-limit");
const path = require("path");

const app = express();
const isProduction = process.env.NODE_ENV === "production";

const required = ["LOGIN_USERNAMES", "LOGIN_PASSWORD_HASH", "SESSION_SECRET"];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`Missing required environment variable: ${key}`);
    process.exit(1);
  }
}

app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"]
    }
  }
}));
app.use(express.urlencoded({ extended: false, limit: "10kb" }));
app.use(cookieSession({
  name: "login_session",
  keys: [process.env.SESSION_SECRET],
  httpOnly: true,
  secure: isProduction,
  sameSite: "strict",
  maxAge: 1000 * 60 * 60 * 8
}));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: "로그인 시도가 너무 많습니다. 잠시 후 다시 시도해 주세요."
});

function requireLogin(req, res, next) {
  if (req.session && req.session.authenticated === true) return next();
  return res.redirect("/");
}

app.get("/", (req, res) => {
  if (req.session && req.session.authenticated === true) {
    return res.redirect("/welcome");
  }
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.post("/login", loginLimiter, async (req, res) => {
  const username = String(req.body.username || "");
  const password = String(req.body.password || "");

  let passwordMatches = false;
  try {
    passwordMatches = await bcrypt.compare(password, process.env.LOGIN_PASSWORD_HASH);
  } catch (_) {
    passwordMatches = false;
  }

  const allowedUsernames = process.env.LOGIN_USERNAMES
    .split(",")
    .map((name) => name.trim())
    .filter(Boolean);

  if (!allowedUsernames.includes(username) || !passwordMatches) {
    return res.status(401).sendFile(path.join(__dirname, "public", "login-error.html"));
  }

  req.session = { authenticated: true };
  return res.redirect("/welcome");
});

app.get("/welcome", requireLogin, (req, res) => {
  res.sendFile(path.join(__dirname, "public", "welcome.html"));
});

app.post("/logout", requireLogin, (req, res) => {
  req.session = null;
  res.redirect("/");
});

app.get("/health", (_req, res) => res.status(200).send("ok"));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Login service listening on port ${port}`));
